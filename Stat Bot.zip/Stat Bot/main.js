const Discord = require('discord.js');
const client = new Discord.Client();

client.once('ready', () => {
    console.log('Connected as ' + client.user.tag);

});

client.on('message', msg => {

    if (msg.content === '-statbot') {

        msg.reply('"-help statbot" for additional commands');

    }

});

client.on('message', msg => {

    if (msg.content === '-help statbot') {

        msg.reply('-league [Summoner Name] or -warzone [Battle.net: Username#[tag]|Activision: Username#[tag]]');

    }

});

client.login('NzU1NTk3MjkwNDk2MDY1Njc4.X2Fm0A.JiTbSmkzjJICB-LTOqfZNJ7v94M');